Visit:

http://64bites.com/ruby-tapas 

for additional materials:

- Instructions on setting up cross-platform IDE for C64 development.
- More videos about programming Commodore 64.
- Short and fun story about testing 64spec.

Happy Hacking! :)
