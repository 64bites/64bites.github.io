Run the following command to create data statements:

ruby make_data.rb

---
For more useful C64 programming resources visit http://64bites.com
